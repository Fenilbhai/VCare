package com.example.vcare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
