import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:vcare/CSearch.dart';
import 'package:vcare/MRegister.dart';
import 'package:vcare/MRegister1.dart';

class Cselection extends StatefulWidget {
  const Cselection({Key? key}) : super(key: key);

  @override
  State<Cselection> createState() => _CselectionState();
}

class _CselectionState extends State<Cselection> {
 @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Selection Page',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold)),
      ),
       
       backgroundColor: Colors.grey[250],
       body: Center(
        child: Column(
          children: [
               SizedBox( 
                    height: 100,
                  ),
            Container(
              height: 150,
              width: 170,
              
              
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => CSearch(),)),
                child: ClipRRect(
                  
                  borderRadius: BorderRadius.circular(12),
                 child: Container( 
                  
                    color: Colors.red[400],
                    padding: EdgeInsets.all(20),
                    child: Image.asset('assets/car.png',
                    color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
                  SizedBox( 
                    height: 140,
                  ),
            Container(
              height: 150,
              width: 170,
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => MRegister1(),)
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
               child: Container( 
                  color: Colors.red[400],
                  padding: EdgeInsets.all(20),
                  child: Image.asset('assets/bike.png',
                  color: Colors.white,
                  ),
                ),
              ),
            ),
            ),
          ],
        )
       ),
    );
  }
}