import 'package:flutter/material.dart';
import 'package:vcare/sp_text_general.dart';
import 'search_mechanic.dart';
import 'sp_text_field.dart';
import 'sp_text_general.dart';
class CSearch extends StatelessWidget{
   CSearch({Key? key}) : super(key: key);
final formKey = GlobalKey<FormState>();
  final _area = TextEditingController();
  final _city = TextEditingController();
  final _state = TextEditingController();
  @override 
  Widget build(BuildContext context){
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title:const Text('Search Mechanic',style: TextStyle(color: Colors.white60,fontWeight: FontWeight.bold,fontSize: 20)),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
      child: Form(
        key: formKey,
      child: Column(
        children: [
            TextFormField(
           // labelText:"State",
           controller: _state,
            decoration: const InputDecoration(
                            labelText: 'State',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
            validator: (value){
              if (value!.isEmpty){
                return "Enter your state";
              }
              return null;
            }
          ),
          SizedBox(
            height: 15,
            ),

            TextFormField(
            //labelText:"City",
            controller: _city,
            decoration: const InputDecoration(
                            labelText: 'City',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
            validator: (value){
              if (value!.isEmpty){
                return "Enter your city";
              }
              return null;
            }
          ),
          SizedBox(
            height: 15,
            ),

            TextFormField(
           // labelText:"Area",
           controller: _area,
            decoration: const InputDecoration(
                            labelText: 'Area',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
            validator: (value){
              if (value!.isEmpty){
                return "Enter your area";
              }
              return null;
            }
          ),
          SizedBox(
            height: 15,
            ),




          ElevatedButton(
             
            onPressed:(){
              if(formKey.currentState!.validate()){
              
              Navigator.push(context, MaterialPageRoute(builder: (context) => SearchedMechanic(
                state: _state.text.trim(),
                area: _area.text.trim(),
                city: _city.text.trim(),
              ),)
              );
              }
            }, child:const Text('Search',style: TextStyle(color: Colors.white,fontWeight: FontWeight.w700),),
            )

        ],
      ),
      ),
    ),
    ),
    );
  }
}