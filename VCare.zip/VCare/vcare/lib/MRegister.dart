import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:vcare/resources/auth_function.dart';
import 'package:vcare/resources/cloud_firstore.dart';

import 'msignin.dart';
import 'registerF.dart';

class MRegister extends StatefulWidget {
  const MRegister({Key? key}) : super(key: key);

  @override
  State<MRegister> createState() => _MRegisterState();
}

class _MRegisterState extends State<MRegister> {
     final TextEditingController _emailController =TextEditingController();
    final TextEditingController _passwordController =TextEditingController();
   final  TextEditingController _nameController =TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return  Scaffold(
        appBar: AppBar(
          title: Text('Mechanic Register',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
          backgroundColor: Colors.lightBlueAccent,
          elevation: 0,
        ),
        backgroundColor: Colors.transparent,
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height-140,
              decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage('assets/register.png'),fit: BoxFit.cover),),
              child:
                 Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                 //     mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                         // padding: EdgeInsets.only(left: 35, top:30),
                          child:const Padding(
                            padding:  EdgeInsets.all(8.0),
                            child: Text('Create\nAccount' , style: TextStyle(
                              color: Colors.white,
                              fontSize: 33
                            ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10.0,),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Form(
                      //  key: formKey,
                        child:Column(
                          children:[
                         Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _nameController,
                          decoration: InputDecoration(
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.black),),
                            enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.white),),
                            hintText: 'Name',
                            hintStyle: TextStyle(color: Colors.white),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
                          ),
                          validator: (value){
                                if (value!.isEmpty){
                                  return "Enter your name";
                                }
                                return null;
                              }
                              ),
                        ),
                      
                          
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: TextFormField(
                              controller: _emailController,
                      decoration: InputDecoration(
                        focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.black),),
                        enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.white),),
                        hintText: 'Email',
                        hintStyle: TextStyle(color: Colors.white),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
                      ),
                      validator: (value){
                                if (value!.isEmpty){
                                  return "Enter your email";
                                }
                                return null;
                              }
                            ),
                          ),
                          
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: TextFormField(
           // labelText:"Area",
           controller: _passwordController,
          // keyboardType: TextInputType.visiblePassword,
          obscureText: true,
            decoration: const InputDecoration(
                            labelText: 'Password',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
            
          ),
                          ),
                          ]
                        )
                          ),
                    ),
                    
                    SizedBox(
                      height: 40,
                    ),
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Color(0xff4c505b),
                      child: IconButton(
                        color: Colors.white,
                        onPressed: (){
                          
                      FirebaseAuthentication().sigUpUser(_emailController.text, _passwordController.text, _nameController.text);  
                      Navigator.push(context, MaterialPageRoute(builder:(context)=> RegisterF()));
                          
                        },
                        icon: Icon(Icons.arrow_forward),
                      ),
                       ),
                         SizedBox(
                      height: 20,
                    ),
                        Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder:(context)=>const MyLogin()));
                      }, child: Text('Sign In', style: TextStyle(
                        decoration: TextDecoration.underline,
                        fontSize: 18,
                        color: Colors.white,
                      ),
                      ),
                      ),
                    ],
                        ),
                  ],
                ),
              ),
            ],
          ),
        ),
      
    );
  }
}