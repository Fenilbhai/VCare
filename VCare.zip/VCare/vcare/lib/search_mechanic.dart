import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:vcare/sp_text_general.dart';
import 'sp_text_field.dart';
import 'sp_text_general.dart';
class SearchedMechanic extends StatefulWidget{
  var state;
  var city;
  var area;
   SearchedMechanic({Key? key,@required this.state,@required this.city,@required this.area}) : super(key: key);

  @override
  State<SearchedMechanic> createState() => _SearchedMechanicState();
}

class _SearchedMechanicState extends State<SearchedMechanic> {
final formKey = GlobalKey<FormState>();

  final _area = TextEditingController();

  final _city = TextEditingController();

  final _state = TextEditingController();

  @override 
  Widget build(BuildContext context){
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title:const Text('Search Mechanic',style: TextStyle(color: Colors.white60,fontWeight: FontWeight.bold,fontSize: 20)),
        ),
        body:  StreamBuilder(
        stream: FirebaseFirestore.instance.collection('Mechanic_Data').where('state', isEqualTo: widget.state).where('city', isEqualTo: widget.city).where('area', isEqualTo: widget.area).snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> streamSnapshot) {
          if (streamSnapshot.hasData) {
            print(widget.area);
            print(widget.city);
            print(widget.state);
            return ListView.builder(
              itemCount: streamSnapshot.data!.docs.length,
              itemBuilder: (ctx, index) =>SizedBox(
           child: Card(
              child: Column(
                children: [
                  
                  Text('Name: ${streamSnapshot.data!.docs[index]['name']}'),
                  Text('Number: ${streamSnapshot.data!.docs[index]['phone number']}'),
                  Text('Email: ${streamSnapshot.data!.docs[index]['email']}'),

                ],
              ),
           ),
              ),
            );
          
        }
        return const CircularProgressIndicator();
        }
        ),
    ),
    );
  }
}