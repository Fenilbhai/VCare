import 'package:flutter/material.dart';

class SPTextFormField extends StatelessWidget {
  const SPTextFormField({Key? key, required this.labelText, this.validator, this.prefixIcon}) : super(key: key);
  final String labelText;
  final String? Function(String? value)? validator;
  final Widget? prefixIcon;
  @override
    Widget build(BuildContext context) {
    return Container(
      child: TextFormField(
        keyboardType: TextInputType.number,
        style: TextStyle(
          color: Colors.red[400],
          fontSize: 13,
        ),
        validator: validator,
        decoration: InputDecoration(
          labelText: labelText,
          labelStyle: const TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
          prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

        ),
      ),
    );
  }
}
