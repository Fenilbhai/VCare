import 'package:flutter/material.dart';
import 'package:vcare/Mselection.dart';
import 'package:vcare/Sselection.dart';

import 'msignin.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.grey[20],
      body: Center(
        child: Container(
          height: 500,
          child: Column(
            children: [
              const Text(
                '\nWelcome',
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w600,
                    color: Colors.red),
              ),
              const Text(
                'To',
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w600,
                    color: Colors.redAccent),
              ),
              const Text(
                'VCare\n \n',
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w600,
                    color: Colors.red),
              ),
              const Text(
                'Start As',
                style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(
                    onPressed: () {Navigator.push(context, MaterialPageRoute(builder:(context)=>const Mselection()));},
                    child: const Text(
                      'Mechanic ',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                  const Text(
                    'OR',
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey),
                  ),
                  ElevatedButton(
                    onPressed: () {Navigator.push(context, MaterialPageRoute(builder:(context)=>const Cselection()));},
                   
                    child: const Text(
                      'Customer',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }
}
