import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:vcare/sp_text_general.dart';
import 'sp_text_field.dart';

class RegisterF extends StatelessWidget {
  RegisterF({Key? key}) : super(key: key);
  final formKey = GlobalKey<FormState>();
  final _number = TextEditingController();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _area = TextEditingController();
  final _city = TextEditingController();
  final _state = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Mechanic Registration Form',
              style: TextStyle(
                  color: Colors.white60,
                  fontWeight: FontWeight.bold,
                  fontSize: 20)),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: formKey,
                  child: Column(
                    children: [
                      TextFormField(
                          controller: _number,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Enter Number',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          // keyboardType: ,
        
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your number";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                          controller: _name,
                          decoration: const InputDecoration(
                            labelText: 'Name',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your Name";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                          controller: _email,
                          decoration: const InputDecoration(
                            labelText: 'Email',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your email";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                          controller: _area,
                          decoration: const InputDecoration(
                            labelText: "Area",
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your area";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                          controller: _city,
                          decoration: const InputDecoration(
                            labelText: "City",
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your city";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      TextFormField(
                          controller: _state,
                          decoration: const InputDecoration(
                            labelText: 'State',
                            labelStyle:  TextStyle(
            color: Colors.black54,
            fontSize: 13,
          ),
         // prefixIcon: prefixIcon,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.black54
            )
          ),
          focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.5,
              color: Colors.red,            )
          ),

          errorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          ),

          focusedErrorBorder:  OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,            )
          )

                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter your state";
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 15,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          formKey.currentState!.validate();
                          FirebaseFirestore.instance.collection('Mechanic_Data')
                              .add({
                                'name': _name.text,
                                'phone number':int.parse(_number.text),
                                'email':_email.text,
                                'city':_city.text,
                                'state':_state.text,
                                'area':_area.text,
        
                                });
                        },
                        child: const Text(
                          'Save Details',
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w700),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
